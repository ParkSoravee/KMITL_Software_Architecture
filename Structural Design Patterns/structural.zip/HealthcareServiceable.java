package edu.parinya.softarchdesign.structural;

public interface HealthcareServiceable {
    void service();
    double getPrice();
}
